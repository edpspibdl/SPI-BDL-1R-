<!-- pilihan member -->

<div class="panel panel-default">
    <div class="panel-heading ">Member</div>
    <div class="panel-body">
        <input type="text" class="form-control" name="namaMember" id="namaMember" placeholder="Nama Member">
        <input type="text" class="form-control" name="kodeMember" id="kodeMember" placeholder="Kode Member">
        <input type="text" class="form-control" name="kodeMonitoringMember" id="kodeMonitoringMember"
            placeholder="Kode Monitoring Member">

        <select class="form-control" name="jenisMember" id="jenisMember">
            <option value="All">All Member</option>
            <option value="Merah">Member Merah</option>
            <option value="Biru">Member Biru</option>
            <option value="OMI">OMI</option>
            <option value="IDM">Indomaret</option>
            <option value="MerahBiru">Merah dan Biru</option>
            <option value="TMI">TMI</option>
            <option value="MerahBiruOmi">Merah Biru dan OMI</option>
            <option value="MerahKlik">Klik Merah</option>
            <option value="BiruKlik">Klik Biru</option>
        </select>
        <!-- list outlet -->
        <select class="form-control" name="kodeOutlet" id="kodeOutlet">
            <option value="All">All Outlet</option>
            <?php
            $query = "SELECT out_kodeoutlet, out_namaoutlet FROM tbmaster_outlet ORDER BY out_kodeoutlet";
            // Create connection to Oracle
            include '../include/koneksi.php';
            try {
              $query = $conn->prepare($query);
              $query->execute();
          } catch (PDOException $e) {
              echo "Error: " . $e->getMessage();
          }

            while ($row = $query->fetch(PDO::FETCH_ASSOC)) { 
              echo '<option value="' . $row['out_kodeoutlet'] . '">' . $row['out_kodeoutlet'] . ' ' . sentence_case($row['out_namaoutlet']) . '</option>';
            }

          ?>
        </select> <!-- akhir list outlet -->

        <!-- list outlet -->
        <select class="form-control" name="kodeSubOutlet" id="kodeSubOutlet">
            <option value="">All Sub Outlet</option>
            <?php
            $query = "SELECT sub_kodesuboutlet, sub_namasuboutlet FROM tbmaster_suboutlet ORDER BY sub_kodesuboutlet";
            // Create connection to Oracle
            include '../include/koneksi.php';
            try {
              $query = $conn->prepare($query);
              $query->execute();
          } catch (PDOException $e) {
              echo "Error: " . $e->getMessage();
          }

            while ($row = $query->fetch(PDO::FETCH_ASSOC)) { 
              echo '<option value="' . $row['sub_kodesuboutlet'] . '">' . $row['sub_kodesuboutlet'] . ' ' . sentence_case($row['sub_namasuboutlet']) . '</option>';
            }

          ?>
        </select> <!-- akhir list outlet -->

        <!-- <input type="text" class="form-control" name="kodeSubOutlet" id="kodeSubOutlet" placeholder="Kode Sub Outlet"> -->
    </div>

</div>