<?php
include '../views/view_spb.php';

$query = "SELECT COUNT(spb.spb_prdcd) AS spb_belum_realisasi
          FROM {$viewSpb} spb
          LEFT JOIN tbmaster_prodmast prd ON spb.spb_prdcd = prd.prd_prdcd
          WHERE spb.spb_prdcd IS NOT NULL
                AND spb.spb_lokasiasal LIKE '%S%'
                AND spb.spb_lokasiasal NOT LIKE '%C%'
                AND spb.spb_lokasitujuan LIKE 'D%'
                AND spb.spb_status = '3'";

// Include your PostgreSQL connection script
include '../_/connection.php';

// Prepare the statement
$stmt = $conn->prepare($query);

// Fetch the result
$spbBelumRealisasi = $stmt->fetchColumn();

// Close the connection if necessary
// $conn = null; // Uncomment if you want to explicitly close the connection
?>
