<?php
// Include PostgreSQL connection script
include '../_/connection.php';

// Define the subquery with an alias
$viewSpb = "
    (
        SELECT COALESCE(spb.spb_recordid, '0') AS spb_status,
               spb.spb_lokasiasal,
               spb.spb_lokasitujuan,
               spb.spb_prdcd,
               spb.spb_deskripsi,
               prd.prd_unit AS spb_unit,
               prd.prd_frac AS spb_frac,
               COALESCE(prd.prd_kodetag, ' ') AS spb_kodetag,
               spb.spb_id,
               spb.spb_qty,
               FLOOR(spb.spb_qty / prd.prd_frac) AS spb_rak_ctn,
               MOD(spb.spb_qty::NUMERIC, prd.prd_frac::NUMERIC) AS spb_rak_pcs,
               spb.spb_minus,
               FLOOR(spb.spb_minus / prd.prd_frac) AS spb_minta_ctn,
               MOD(spb.spb_minus::NUMERIC, prd.prd_frac::NUMERIC) AS spb_minta_pcs,
               CASE
                   WHEN spb.spb_jenis = 'MANUAL' THEN 'MANUAL'
                   WHEN spb.spb_jenis = 'OTOMATIS' AND LEFT(spb.spb_lokasitujuan, 1) IN ('G', 'D') THEN 'GUDANG AUTO'
                   ELSE 'TOKO AUTO'
               END AS spb_jenis,
               DATE_TRUNC('day', CURRENT_DATE) - DATE_TRUNC('day', spb.spb_create_dt) AS spb_hari_tertunda,
               CASE
                   WHEN EXTRACT(HOUR FROM COALESCE(spb.spb_create_dt, CURRENT_TIMESTAMP)) < 8
                   THEN FLOOR(EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - COALESCE(spb.spb_create_dt, CURRENT_TIMESTAMP))) / 3600) - 8
                   ELSE FLOOR(EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - COALESCE(spb.spb_create_dt, CURRENT_TIMESTAMP))) / 3600)
               END AS spb_jam_tertunda
        FROM tbtemp_antrianspb spb
        LEFT JOIN tbmaster_prodmast prd ON spb.spb_prdcd = prd.prd_prdcd
        WHERE spb.spb_prdcd IS NOT NULL
          AND spb.spb_prdcd IN (SELECT spb_prdcd FROM (SELECT spb_prdcd FROM tbtemp_antrianspb) AS subquery_alias)
    ) AS view_spb";

	

// Define your PostgreSQL query
$query = "SELECT spb_jenis, spb_prdcd, spb_unit, spb_frac, spb_kodetag, 
                 spb_hari_tertunda, SPB_JAM_TERTUNDA, spb_lokasiasal, 
                 spb_minta_ctn, spb_lokasitujuan, spb_deskripsi
          FROM {$viewSpb}
          WHERE spb_prdcd IS NOT NULL
                AND spb_lokasiasal LIKE '%S%'
                AND spb_lokasiasal NOT LIKE '%C%'";

// Prepare the statement
$stmt = $conn->prepare($query);
$stmt->execute();

// Fetch each row as an associative array
$noUrut = 0;
?>

<div class="panel bayang">
  <div class="table-responsive">
    <table class="table table-bordered table-striped table-hover">
      <thead>
        <tr class="info">
          <th>#</th>
          <th>Asal</th>
          <th>Tujuan</th>
          <th>Nama Barang</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
          $noUrut++;
          
          // Determine infoJenis
          if ($row['spb_jenis'] == 'MANUAL') {
            $infoJenis = '<span class="badge">Manual</span>';
          } else {
            $infoJenis = '';
          }
          
          // Construct infoProduk
          $infoProduk = $row['spb_prdcd'] . ' - ' . $row['spb_unit'] . ' / ' . $row['spb_frac'] . ' ' . $row['spb_kodetag'];
          
          // Determine infoTertunda
          switch ($row['spb_hari_tertunda']) {
            case 0:
              if ($row['SPB_JAM_TERTUNDA'] >= 2) {
                $infoTertunda = '<span class="label label-danger"> ' . $row['SPB_JAM_TERTUNDA'] . ' jam yang lalu</span>';
              } elseif ($row['SPB_JAM_TERTUNDA'] == 1) {
                $infoTertunda = '<span class="label label-primary"> ' . $row['SPB_JAM_TERTUNDA'] . ' jam yang lalu</span>';
              } elseif ($row['SPB_JAM_TERTUNDA'] == 0) {
                $infoTertunda = ' ';
              }
              break;
            case 1:
              $infoTertunda = '<span class="label label-danger"> Kemarin</span>';
              break;
            default:
              $infoTertunda = '<span class="label label-danger"> ' . $row['spb_hari_tertunda'] . ' hari yang lalu</span>';
          }
          
          // Output each row
          echo '<tr>';
          echo '<td align="center"><h4>' . $noUrut . '</h4></td>';
          echo '<td align="left"><h4>' . $row['spb_lokasiasal'] . '</h4>' . $row['spb_minta_ctn'] . ' - ' . $row['spb_unit'] . '</td>';
          echo '<td align="left"><h4>' . $row['spb_lokasitujuan'] . '</h4>' . $infoJenis . '</td>';
          echo '<td align="left"><h4>' . $row['spb_deskripsi'] . '</h4>' . $infoProduk . ' ' . $infoTertunda . '</td>';
          echo '</tr>';
        } ?>
      </tbody>
    </table>
  </div>
</div>
