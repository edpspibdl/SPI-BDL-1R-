<?php require_once '../layout/_top.php'; ?>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    padding: 40px;
  }
  .container {
    max-width: 400px;
    margin: auto;
    background: white;
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
  }
  h2 {
    text-align: center;
    margin-bottom: 25px;
  }
  .warning-dev {
    background-color: #fff3cd;
    color: #856404;
    border: 1px solid #ffeeba;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 20px;
    text-align: center;
    font-weight: bold;
  }
  .input-group {
    position: relative;
    margin-bottom: 15px;
  }
  input[type="text"] {
    width: 100%;
    padding: 10px 40px 10px 12px;
    border-radius: 5px;
    border: 1px solid #ccc;
  }
  .icon-eye {
    position: absolute;
    right: 12px;
    top: 10px;
    cursor: pointer;
    font-size: 20px;
  }
  input[type="submit"] {
    width: 100%;
    padding: 12px;
    background: #007BFF;
    color: white;
    border: none;
    border-radius: 5px;
    font-weight: bold;
  }

  .modal {
    display: none;
    position: fixed;
    z-index: 9999;
    left: 0; top: 0;
    width: 100%; height: 100%;
    background: rgba(0,0,0,0.5);
    justify-content: center;
    align-items: center;
  }
  .modal.show {
    display: flex;
  }
  .modal-content {
    background: white;
    width: 90%;
    max-width: 800px;
    max-height: 80vh;
    overflow: auto;
    border-radius: 8px;
    padding: 20px;
    position: relative;
  }
  .modal-close {
    position: absolute;
    right: 15px;
    top: 10px;
    font-size: 24px;
    cursor: pointer;
  }
  table.dataTable tbody tr {
    cursor: pointer;
  }
</style>
</head>
<body>

<div class="container">
  <div class="warning-dev">
    ⚠️ Menu ini sedang dalam tahap pengembangan.
  </div>

  <h2>Cari Produk</h2>
  <form action="index.php" method="GET">
    <label for="kodePLU">Masukkan Kode PLU:</label>
    <div class="input-group">
      <input type="text" id="kodePLU" name="kodePLU" required placeholder="Contoh: 0013500">
      <span class="icon-eye" id="openModal">&#128269;</span>
    </div>
    <input type="submit" value="Cari Produk">
  </form>
</div>

<!-- MODAL -->
<div id="pluModal" class="modal" aria-hidden="true">
  <div class="modal-content">
    <span class="modal-close" id="modalCloseBtn">&times;</span>
    <h3>Daftar PLU Produk</h3>
    <table id="pluTable" class="display" style="width:100%">
      <thead>
        <tr>
          <th>PLU</th>
          <th>Deskripsi Panjang</th>
        </tr>
      </thead>
      <tbody>
        <?php
        require_once '../helper/connection.php';

        try {
          $stmt = $conn->query("SELECT PRD_PRDCD, PRD_DESKRIPSIPANJANG FROM TBMASTER_PRODMAST 
          WHERE PRD_RECORDID IS NULL 
          and prd_prdcd like '%0'
          ORDER BY PRD_PRDCD ASC");
          while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $prdcd = htmlspecialchars($row['prd_prdcd']);
            $desc = htmlspecialchars($row['prd_deskripsipanjang']);
            echo "<tr data-plu='$prdcd'><td>$prdcd</td><td>$desc</td></tr>";
          }
        } catch (PDOException $e) {
          echo '<tr><td colspan="2">Error: ' . htmlspecialchars($e->getMessage()) . '</td></tr>';
        }
        ?>
      </tbody>
    </table>
  </div>
</div>

<script>
  $(document).ready(function () {
    const modal = document.getElementById('pluModal');
    const openBtn = document.getElementById('openModal');
    const closeBtn = document.getElementById('modalCloseBtn');
    const inputPLU = document.getElementById('kodePLU');

    // Inisialisasi DataTable
    const dataTable = $('#pluTable').DataTable();

    // Tampilkan modal
    openBtn.addEventListener('click', () => {
      modal.classList.add('show');
      dataTable.draw(); // refresh layout
    });

    // Tutup modal
    closeBtn.addEventListener('click', () => {
      modal.classList.remove('show');
    });

    // Klik luar modal = tutup
    window.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.remove('show');
      }
    });

    // Klik baris = isi input
    $('#pluTable tbody').on('click', 'tr', function () {
      const plu = $(this).data('plu');
      $('#kodePLU').val(plu);
      modal.classList.remove('show');
    });
  });
</script>

<?php require_once '../layout/_bottom.php'; ?>
