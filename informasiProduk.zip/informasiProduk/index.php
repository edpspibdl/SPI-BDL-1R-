<?php
require_once '../layout/_top.php';
require_once '../helper/connection.php';

$kodePLU = isset($_GET['kodePLU']) && $_GET['kodePLU'] !== "" ? str_pad($_GET['kodePLU'], 7, '0', STR_PAD_LEFT) : '';
$data = [];
$barcodes = [];

if ($kodePLU !== '') {
    try {
        // Query 1: Informasi produk utama
        $stmt = $conn->prepare("SELECT DISTINCT ON (prd_prdcd)
            prd_prdcd,
            prd_deskripsipanjang,
            prd_kategoritoko,
            prd_kodecabang,
            prd_flaggudang,
            prd_create_dt,
            prd_kodedivisi || '   ' || COALESCE(div_namadivisi, '') || ' - ' || 
            COALESCE(prd_kodekategoribarang, '') || '  ' || COALESCE(kat_namakategori, '') || ' - ' ||
            COALESCE(prd_kodedepartement, '') || '  ' || COALESCE(dep_namadepartement, '') AS div_dept_kat
        FROM tbmaster_prodmast
        LEFT JOIN tbmaster_divisi ON prd_kodedivisi = div_kodedivisi
        LEFT JOIN tbmaster_departement ON prd_kodedepartement = dep_kodedepartement
        LEFT JOIN tbmaster_kategori ON prd_kodekategoribarang = kat_kodekategori
        WHERE prd_prdcd = :kodePLU");
        $stmt->bindParam(':kodePLU', $kodePLU, PDO::PARAM_STR);
        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        // Query 2: Barcode and Promo Price Data
        $stmt2 = $conn->prepare("SELECT 
    pm.PRD_KODEDIVISI,
    pm.PRD_KODEDEPARTEMENT,
    pm.PRD_PRDCD,
    pm.PRD_DESKRIPSIPANJANG,
    pm.PRD_UNIT,
    pm.PRD_FRAC,
    pm.PRD_HRGJUAL,
    pm.PRD_KODETAG,
    pc.PRC_KODETAG,
    pm.PRD_FLAG_AKTIVASI,
    pm.PRD_AVGCOST,
    pm.PRD_LASTCOST,
    pm.PRD_MINJUAL,
    md.PRMD_HRGJUAL,
    md.PRMD_TGLAWAL,
    md.PRMD_TGLAKHIR,
    bc.BRC_BARCODE,

    -- Hitung margin berdasarkan flag BKP
    CASE 
        WHEN pm.PRD_FLAGBKP1 = 'Y' AND pm.PRD_FLAGBKP2 = 'Y' 
            THEN ((pm.PRD_HRGJUAL - (pm.PRD_AVGCOST * 1.11)) / pm.PRD_HRGJUAL * 100)
        WHEN pm.PRD_FLAGBKP1 IS NULL AND pm.PRD_FLAGBKP2 IN ('N','C') 
            THEN ((pm.PRD_HRGJUAL - pm.PRD_AVGCOST) / pm.PRD_HRGJUAL * 100)
    END AS MARGIN,

            ROUND(
            CASE         
                    WHEN pm.PRD_FLAGBKP1 = 'Y' AND pm.PRD_FLAGBKP2 = 'Y' THEN ((pm.PRD_HRGJUAL - pm.PRD_AVGCOST * 1.11) / pm.PRD_HRGJUAL) * 100   
                    WHEN pm.PRD_FLAGBKP1 = 'Y' AND pm.PRD_FLAGBKP2 <> 'Y' THEN ((pm.PRD_HRGJUAL - pm.PRD_AVGCOST) / pm.PRD_HRGJUAL) * 100    
                    WHEN pm.PRD_FLAGBKP1 = 'N' THEN ((pm.PRD_HRGJUAL - pm.PRD_AVGCOST) / pm.PRD_HRGJUAL) * 100    
                END, 2
            ) AS MARGINACOST, 

            ROUND(
                CASE         
                    WHEN pm.PRD_FLAGBKP1 = 'Y' AND pm.PRD_FLAGBKP2 = 'Y' THEN ((pm.PRD_HRGJUAL - pm.PRD_LASTCOST * 1.11) / pm.PRD_HRGJUAL) * 100  
                    WHEN pm.PRD_FLAGBKP1 = 'Y' AND pm.PRD_FLAGBKP2 <> 'Y' THEN ((pm.PRD_HRGJUAL - pm.PRD_LASTCOST) / pm.PRD_HRGJUAL) * 100  
                    WHEN pm.PRD_FLAGBKP1 = 'N' THEN ((pm.PRD_HRGJUAL - pm.PRD_LASTCOST) / pm.PRD_HRGJUAL) * 100        
                END, 2
            ) AS MARGINLCOST,

    -- KALI: nilai pengali PPN
    CASE 
        WHEN pm.PRD_FLAGBKP1 = 'Y' AND pm.PRD_FLAGBKP2 = 'Y' THEN 1.11
        WHEN pm.PRD_FLAGBKP1 = 'N' AND pm.PRD_FLAGBKP2 IN ('N','C') THEN 1
    END AS KALI,

    -- ST_HARGA_NETTO
    CASE 
        WHEN COALESCE(pm.prd_flagbkp1,'T') = 'Y' AND COALESCE(pm.prd_flagbkp2,'T') = 'Y' 
            THEN pm.PRD_HRGJUAL / 11.1 * 10
        ELSE pm.PRD_HRGJUAL
    END AS ST_HARGA_NETTO,

    -- ST_MD_NETTO
    CASE 
        WHEN COALESCE(pm.prd_flagbkp1,'T') = 'Y' AND COALESCE(pm.prd_flagbkp2,'T') = 'Y' 
            THEN md.PRMD_HRGJUAL / 11.1 * 10
        ELSE md.PRMD_HRGJUAL
    END AS ST_MD_NETTO,

    -- Kolom satuan jual berdasarkan digit terakhir PRD_PRDCD
    CASE 
        WHEN RIGHT(pm.PRD_PRDCD, 1) = '0' THEN '0'
        WHEN RIGHT(pm.PRD_PRDCD, 1) = '1' THEN '1'
        WHEN RIGHT(pm.PRD_PRDCD, 1) = '2' THEN '2'
        WHEN RIGHT(pm.PRD_PRDCD, 1) = '3' THEN '3'
        ELSE NULL
    END AS sj,

    pm.PRD_FLAGBKP1,
    pm.PRD_FLAGBKP2

FROM tbmaster_prodmast pm

LEFT JOIN (
    SELECT prmd_prdcd, prmd_hrgjual, prmd_tglawal, prmd_tglakhir
    FROM tbtr_promomd
    WHERE CURRENT_DATE BETWEEN prmd_tglawal AND prmd_tglakhir
) md ON pm.prd_prdcd = md.prmd_prdcd

LEFT JOIN tbmaster_prodcrm pc ON pm.prd_prdcd = pc.prc_pluigr

-- Ambil hanya 1 barcode per produk menggunakan DISTINCT ON
LEFT JOIN (
    SELECT DISTINCT ON (brc_prdcd) brc_prdcd, brc_barcode
    FROM tbmaster_barcode
    ORDER BY brc_prdcd, brc_barcode  -- Pilih barcode terkecil (atau ubah sesuai kebutuhan)
) bc ON pm.prd_prdcd = bc.brc_prdcd

WHERE pm.PRD_PRDCD LIKE :kodePLU

ORDER BY pm.PRD_MINJUAL, pm.PRD_AVGCOST DESC");

        // Update kodePLU for LIKE clause
        $kodePLU = substr($kodePLU, 0, 6) . '%';
        $stmt2->bindParam(':kodePLU', $kodePLU, PDO::PARAM_STR);
        $stmt2->execute();

        // Fetch all barcode and product data
        $barcodes = $stmt2->fetchAll(PDO::FETCH_ASSOC);


// QUERY 3 :: TREN SALED

        $stmt3 = $conn->prepare("SELECT a.*,
			  ST_SALES,
			  CASE
			    WHEN p.PRD_UNIT = 'KG'
			    AND p.PRD_FRAC  = 1000
			    THEN (ST_SALES*ST_AVGCOST)/ p.prd_frac
			    ELSE ST_SALES *ST_AVGCOST
			  END HPP
			FROM TBTR_SALESBULANAN a
			LEFT JOIN TBMASTER_STOCK b
			ON a.SLS_PRDCD = b.ST_PRDCD
			LEFT JOIN tbmaster_prodmast p
			ON a.SLS_PRDCD  = p.PRD_PRDCD
			WHERE ST_LOKASI ='01'
			AND SLS_PRDCD LIKE :kodePLU");

        // Update kodePLU for LIKE clause
        $kodePLU = substr($kodePLU, 0, 6) . '%';
        $stmt3->bindParam(':kodePLU', $kodePLU, PDO::PARAM_STR);
        $stmt3->execute();

        // Fetch all barcode and product data
        $trensale = $stmt3->fetchAll(PDO::FETCH_ASSOC);


// QUERY 4 :: STOCK

        $stmt4 = $conn->prepare("SELECT st_lokasi ,
				  CASE
					WHEN st_lokasi ='01'
					THEN 'BK'
					WHEN st_lokasi ='02'
					THEN 'RT'
					WHEN st_lokasi ='03'
					THEN 'RS'
				  END AS lokasi,
				  st_prdcd ,
				  st_saldoawal ,
				  st_trfin,
				  st_trfout,
				  st_sales ,
				  st_retur ,
				  st_adj ,
				  st_intransit ,
				  st_so + st_selisih_soic as so ,
				  st_saldoakhir,
                  st_saldoakhir_lpp
				FROM tbmaster_stock
				WHERE st_prdcd like :kodePLU
				ORDER BY 1");

        // Update kodePLU for LIKE clause
        $kodePLU = substr($kodePLU, 0, 6) . '%';
        $stmt4->bindParam(':kodePLU', $kodePLU, PDO::PARAM_STR);
        $stmt4->execute();

        // Fetch all barcode and product data
        $stok = $stmt4->fetchAll(PDO::FETCH_ASSOC);


        // QUERY 5 :: STOCK

        $stmt5 = $conn->prepare("SELECT cbd_prdcd,
                    cbd_kodepromosi,
                    cbh_namapromosi,
                    cbd_minstruk,
                    cbh_minrphprodukpromo,
                    cbh_mintotbelanja,
                    CASE
                      WHEN COALESCE(cbd_cashback, 0) = 0
                      THEN cbh_cashback
                      ELSE cbd_cashback
                    END AS CBD_CASHBACK,
                    cba_alokasijumlah - cbk_cashback_qty as cbk_sisa,
                    cbd_maxstruk,
                    cbd_maxmemberperhari,
                    cbd_maxfrekperevent,
                    cbd_maxrphperevent,
                    CBD_ALOKASISTOK,
                    cbh_tglawal,
                    cbh_tglakhir,
                    cbd_flagkelipatan,                    
                    cba_reguler,
                    cba_reguler_biruplus,
                    cba_freepass,
                    cba_retailer,
                    cba_silver,
                    cba_gold1,
                    cba_gold2,
                    cba_gold3,
                    cba_platinum
              FROM tbtr_cashback_dtl d
              LEFT JOIN tbtr_cashback_hdr h
                ON d.cbd_kodepromosi = h.cbh_kodepromosi
              LEFT JOIN tbtr_cashback_alokasi a
                ON d.cbd_kodepromosi = a.cba_kodepromosi
              LEFT JOIN (SELECT kd_promosi AS cbk_kodepromosi, SUM(kelipatan)  AS cbk_cashback_qty FROM m_promosi_h GROUP BY kd_promosi) k
                ON d.cbd_kodepromosi = k.cbk_kodepromosi
              WHERE CURRENT_DATE BETWEEN h.cbh_tglawal AND h.cbh_tglakhir
                    AND (cbh_kodeigr = '1R' and cba_kodecabang = '1R')
                    AND COALESCE(cbd_recordid, '2') <> '1'
                    AND d.cbd_prdcd LIKE :kodePLU 
              ORDER BY h.cbh_tglawal ASC");

        // Update kodePLU for LIKE clause
        $kodePLU = substr($kodePLU, 0, 6) . '%';
        $stmt5->bindParam(':kodePLU', $kodePLU, PDO::PARAM_STR);
        $stmt5->execute();

        // Fetch all barcode and product data
        $csbk = $stmt5->fetchAll(PDO::FETCH_ASSOC);


        // QUERY 6 :: HARGA MEMBER BMP

        $stmt6 = $conn->prepare("SELECT PLU,
       HRGMM,
       CBMM,
       HRG_NETMM,
       HRGBIRU,
       CBBIRU,
       HRG_NETBIRU,
       HRGPLA,
       CBPLA,
       HRG_NETPLA
FROM (       
SELECT PRD_PRDCD PLU
FROM TBMASTER_PRODMAST WHERE PRD_PRDCD LIKE :kodePLU   )prd
LEFT JOIN (
select PLUMM,
       HRGMM,
       CBMM,
       HRG_NETMM
from (
select pluN plumm, HRGN,
       HRGP,
       (CASE WHEN PLUN LIKE '%0' THEN HRG  ELSE ( HRG * QTY) END ) HRGMM,
       qty qtymm,
       cb cbmm,
       (round(((CASE WHEN PLUN LIKE '%0' THEN HRG  ELSE ( HRG * QTY) END )),0)-coalesce(cb,0)) hrg_netmm 
from ( 
select pluN,  HRGN,
       HRGP,
       hrg,qty, 
       sum((jmlcbh*cbh)+(jmlcbd*cbd)) CB 
from ( 
select distinct pluN, 
       MINRPHC,
       MINJUALC,
       MAXJUALC,
       MAXRPHC, 
       cbd, 
       cbh,
        HRGN,
       HRGP,
       hrg,
       qty,
       sum(case when pluN like '%0' 
            then (case when coalesce(MINRPHC,0)<>'0' 
                          then  ( case when (hrg) > MAXRPHC 
                                       then FLOOR(MAXRPHC/MINRPHC) 
                                       else FLOOR((hrg)/MINRPHC) 
                                       end ) 
                          else 0 
                          end )
            else (case when coalesce(MINRPHC,0)<>'0' 
                          then  ( case when (hrg*qty) > MAXRPHC 
                                       then FLOOR(MAXRPHC/MINRPHC) 
                                       else FLOOR((hrg*qty)/MINRPHC) 
                                       end ) 
                          else 0 
                          end )
            end )jmlcbh, 
       sum(case when coalesce(MINJUALC,0)<>'0' 
              then  (CASE WHEN UNIT='RCG' THEN FLOOR((QTY*FRACN)/MINJUALC) ELSE
                   ( case when qty > MAXJUALC
                          then FLOOR(MAXJUALC/MINJUALC) 
                          else FLOOR(qty/MINJUALC) 
                          end )END )
             else 0 
             end ) jmlcbd 
from (
SELECT PLUN,
       DESK,
     FRACN,
     UNIT,
       (CASE WHEN UNIT LIKE '%RCG%'
             THEN ( 1 * MINJUALN )
             ELSE ( FRACN*MINJUALN) 
             END ) QTY,
       HRGN,
       HRGP,
       (CASE WHEN coalesce(HRGP,0)='0' THEN HRGN ELSE HRGP END ) HRG,
       MINRPHC,
       MINJUALC,
       MAXJUALC,
       MAXRPHC,
       CBH,
       CBD
FROM (
SELECT PLUN,
       DESK,
       FRACN,
     UNIT,
       MINJUALN,
       HRGN,
       HRGP
FROM ( 
SELECT PLUP,HRGP,FLAG FROM 
(SELECT DISTINCT PRMD_PRDCD PLUP,
        PRMD_HRGJUAL HRGP,
        (CASE WHEN ALK_MEMBER='PLATINUM' THEN 'PLATINUM'
              WHEN (ALK_MEMBER='REGBIRUPLUS' OR ALK_MEMBER='REGBIRU') THEN 'BIRU'
              ELSE 'MERAH' END ) FLAG
FROM TBTR_PROMOMD LEFT JOIN TBTR_PROMOMD_ALOKASI ON SUBSTR(PRMD_PRDCD,1,6)||0=ALK_PRDCD
WHERE date_trunc('day',PRMD_TGLAWAL)<=now() AND date_trunc('day',PRMD_TGLAKHIR)>=now()
 AND PRMD_PRDCD LIKE :kodePLU  ) rcg2 WHERE FLAG='MERAH' ) rcg1
RIGHT JOIN ( 
SELECT PRD_PRDCD PLUN,
       PRD_DESKRIPSIPANJANG DESK,
       PRD_FRAC FRACN,
     PRD_UNIT UNIT,
       PRD_MINJUAL MINJUALN,
       PRD_HRGJUAL HRGN
FROM TBMASTER_PRODMAST
WHERE PRD_PRDCD  LIKE :kodePLU   ) plu4 ON PLUN=PLUP ) rcg3
LEFT JOIN (
SELECT PLUC,
       MINRPHC,
       MINJUALC,
       MAXJUALC,
       MAXRPHC,
       CBH,
       CBD 
FROM (
select cbd_kodepromosi kode, 
       cbd_prdcd pluC, 
      (case when cbh_minrphprodukpromo < cbh_mintotbelanja then cbh_mintotbelanja 
            when cbh_minrphprodukpromo >0 then cbh_minrphprodukpromo 
            else cbh_mintotbelanja 
            end ) minrphC, 
       cbd_minstruk minjuALC, 
       (case when cbd_maxstruk='999999' then 999999999 else cbd_maxstruk end) maxjuALC, 
       (case when cbh_maxstrkperhari='999999' then 999999999 else cbh_maxstrkperhari end) maxrphC, 
       cbh_cashback cbh, 
       cbd_cashback cbd 
from tbtr_cashback_hdr left join tbtr_cashback_dtl on cbh_kodepromosi=cbd_kodepromosi 
                       left join tbtr_cashback_alokasi on cbh_kodepromosi=cba_kodepromosi 
where date_trunc('day',cbh_tglakhir)>=now() and date_trunc('day',cbh_tglawal)<= now() 
  and ( coalesce(cba_retailer,'0')='1' or coalesce(cba_silver,'0')='1' or coalesce(cba_gold1,'0')='1' or coalesce(cba_gold2,'0')='1' or coalesce(cba_gold2,'0')='1' ) 
  and cbh_namapromosi not like '%UNIQUE%' 
  and cbh_namapromosi not like '%PWP%' 
  and cbh_namapromosi not like '%KLIK IGR%' 
  and cbh_namapromosi not like '%ISAKU%'
  and cbh_namapromosi not like '%UNICODE%' 
  and cbh_kodepromosi not in ('CS784','CS783')
  and coalesce(cbd_recordid,'2') <>'1' 
  and  coalesce(cbd_redeempoint,0)='0' ) cb1 WHERE PLUC LIKE :kodePLU   ) cb2 ON SUBSTR(PLUN,1,6)||0=PLUC) cb3 
group by PLUN, MINRPHC, MINJUALC, MAXJUALC, MAXRPHC, cbd, cbh, HRGN, HRGP, hrg, qty )cb6 group by pluN, HRGN, HRGP, hrg, qty)cb4)cb5
ORDER BY PLUMM ) prd2 ON PLU=PLUMM
LEFT JOIN (
select PLUBIRU,
       HRGBIRU,
       CBBIRU,
       HRG_NETBIRU
from (
select pluN pluBIRU, HRGN,
       HRGP,
       (CASE WHEN PLUN LIKE '%0' THEN HRG  ELSE ( HRG * QTY) END ) HRGBIRU,
       qty qtyBIRU,
       cb cbBIRU,
       (round(((CASE WHEN PLUN LIKE '%0' THEN HRG  ELSE ( HRG * QTY) END )),0)-coalesce(cb,0)) hrg_netBIRU 
from ( 
select pluN,  HRGN,
       HRGP,
       hrg,qty, 
       sum(coalesce((jmlcbh*cbh),0)+coalesce((jmlcbd*cbd),0)) CB 
from ( 
select distinct pluN, 
       MINRPHC,
       MINJUALC,
       MAXJUALC,
       MAXRPHC, 
       cbd, 
       cbh,
       HRGN,
       HRGP,
       hrg,
       qty,
       sum(case when pluN like '%0' 
            then (case when coalesce(MINRPHC,0)<>'0' 
                          then  ( case when (hrg) > MAXRPHC 
                                       then FLOOR(MAXRPHC/MINRPHC) 
                                       else FLOOR((hrg)/MINRPHC) 
                                       end ) 
                          else 0 
                          end )
            else (case when coalesce(MINRPHC,0)<>'0' 
                          then  ( case when (hrg*qty) > MAXRPHC 
                                       then FLOOR(MAXRPHC/MINRPHC) 
                                       else FLOOR((hrg*qty)/MINRPHC) 
                                       end ) 
                          else 0 
                          end )
            end )jmlcbh, 
       sum(case when coalesce(MINJUALC,0)<>'0' 
             then  (CASE WHEN UNIT='RCG' THEN FLOOR((QTY*FRACN)/MINJUALC) ELSE
                   ( case when qty > MAXJUALC
                          then FLOOR(MAXJUALC/MINJUALC) 
                          else FLOOR(qty/MINJUALC) 
                          end )END )
             else 0 
             end ) jmlcbd 
from (
SELECT PLUN,
       DESK,
     FRACN,
     UNIT,
       (CASE WHEN UNIT LIKE '%RCG%'
             THEN ( 1 * MINJUALN )
             ELSE ( FRACN*MINJUALN) 
             END ) QTY,
       HRGN,
       HRGP,
       coalesce((CASE WHEN coalesce(HRGP,0)='0' THEN HRGN ELSE HRGP END ),0) HRG,
       MINRPHC,
       MINJUALC,
       MAXJUALC,
       MAXRPHC,
       CBH,
       CBD
FROM (
SELECT PLUN,
       DESK,
       FRACN,
     UNIT,
       MINJUALN,
       HRGN,
       HRGP
FROM ( 
SELECT PLUP,HRGP,FLAG FROM 
(SELECT DISTINCT PRMD_PRDCD PLUP,
        coalesce(PRMD_HRGJUAL,0) HRGP,
        (CASE WHEN ALK_MEMBER='PLATINUM' THEN 'PLATINUM'
              WHEN (ALK_MEMBER='REGBIRUPLUS' OR ALK_MEMBER='REGBIRU') THEN 'BIRU'
              ELSE 'MERAH' END ) FLAG
FROM TBTR_PROMOMD LEFT JOIN TBTR_PROMOMD_ALOKASI ON SUBSTR(PRMD_PRDCD,1,6)||0=ALK_PRDCD
WHERE date_trunc('day',PRMD_TGLAWAL)<=now() AND date_trunc('day',PRMD_TGLAKHIR)>=now()
 AND PRMD_PRDCD LIKE :kodePLU   ) hj1 WHERE FLAG='BIRU' ) hj_blu
RIGHT JOIN ( 
SELECT PRD_PRDCD PLUN,
       PRD_DESKRIPSIPANJANG DESK,
       PRD_FRAC FRACN,
     PRD_UNIT UNIT,
       PRD_MINJUAL MINJUALN,
       PRD_HRGJUAL HRGN
FROM TBMASTER_PRODMAST
WHERE PRD_PRDCD LIKE :kodePLU   ) prd6 ON PLUN=PLUP ) prd7
LEFT JOIN (
SELECT PLUC,
       MINRPHC,
       MINJUALC,
       MAXJUALC,
       MAXRPHC,
       CBH,
       CBD 
FROM (
select cbd_kodepromosi kode, 
       cbd_prdcd pluC, 
      (case when cbh_minrphprodukpromo < cbh_mintotbelanja then cbh_mintotbelanja 
            when cbh_minrphprodukpromo >0 then cbh_minrphprodukpromo 
            else cbh_mintotbelanja 
            end ) minrphC, 
       cbd_minstruk minjuALC, 
       (case when cbd_maxstruk='999999' then 999999999 else cbd_maxstruk end) maxjuALC, 
       (case when cbh_maxstrkperhari='999999' then 999999999 else cbh_maxstrkperhari end) maxrphC, 
       coalesce(cbh_cashback,0) cbh, 
       coalesce(cbd_cashback,0) cbd 
from tbtr_cashback_hdr left join tbtr_cashback_dtl on cbh_kodepromosi=cbd_kodepromosi 
                       left join tbtr_cashback_alokasi on cbh_kodepromosi=cba_kodepromosi 
where date_trunc('day',cbh_tglakhir)>=now() and date_trunc('day',cbh_tglawal)<=now() 
  and ( coalesce(cba_REGULER,'0')='1' or coalesce(cba_REGULER_BIRUPLUS,'0')='1') 
  and cbh_namapromosi not like '%UNIQUE%' 
  and cbh_namapromosi not like '%PWP%' 
  and cbh_namapromosi not like '%KLIK IGR%' 
  and cbh_namapromosi not like '%ISAKU%'
  and cbh_namapromosi not like '%UNICODE%'  
  and cbh_kodepromosi not in ('CS784','CS783')
  and coalesce(cbd_recordid,'2') <>'1' 
  and  coalesce(cbd_redeempoint,0)='0' ) prd8 WHERE PLUC LIKE '{$kodePLU}%'  ) prd9 ON SUBSTR(PLUN,1,6)||0=PLUC) prd10
group by PLUN, MINRPHC, MINJUALC, MAXJUALC, MAXRPHC, cbd, cbh, HRGN, HRGP, hrg, qty ) prd11 group by pluN, HRGN, HRGP, hrg, qty)prd12)prd13
ORDER BY PLUBIRU )prd3 ON PLU=PLUBIRU
LEFT JOIN (
select PLUPLA,
       HRGPLA,
       CBPLA,
       HRG_NETPLA
from (
select pluN pluPLA, HRGN,
       HRGP,
       (CASE WHEN PLUN LIKE '%0' THEN HRG  ELSE ( HRG * QTY) END ) HRGPLA,
       qty qtyPLA,
       cb cbPLA,
       (round(((CASE WHEN PLUN LIKE '%0' THEN HRG  ELSE ( HRG * QTY) END )),0)-coalesce(cb,'0')) hrg_netPLA 
from ( 
select pluN,  HRGN,
       HRGP,
       hrg,qty, 
       sum(coalesce((jmlcbh*cbh),'0')+coalesce((jmlcbd*cbd),'0')) CB 
from ( 
select distinct pluN, 
       MINRPHC,
       MINJUALC,
       MAXJUALC,
       MAXRPHC, 
       cbd, 
       cbh,
        HRGN,
       HRGP,
       hrg,
       qty,
       sum(case when pluN like '%0' 
            then (case when coalesce(MINRPHC,'0')<>'0' 
                          then  ( case when (hrg) > MAXRPHC 
                                       then FLOOR(MAXRPHC/MINRPHC) 
                                       else FLOOR((hrg)/MINRPHC) 
                                       end ) 
                          else 0 
                          end )
            else (case when coalesce(MINRPHC,'0')<>'0' 
                          then  ( case when (hrg*qty) > MAXRPHC 
                                       then FLOOR(MAXRPHC/MINRPHC) 
                                       else FLOOR((hrg*qty)/MINRPHC) 
                                       end ) 
                          else 0 
                          end )
            end )jmlcbh, 
       sum(case when coalesce(MINJUALC,'0')<>'0' 
              then  (CASE WHEN UNIT='RCG' THEN FLOOR((QTY*FRACN)/MINJUALC) ELSE
                   ( case when qty > MAXJUALC
                          then FLOOR(MAXJUALC/MINJUALC) 
                          else FLOOR(qty/MINJUALC) 
                          end )END )
             else 0 
             end ) jmlcbd 
from (
SELECT PLUN,
       DESK,
     FRACN,
     UNIT,
       (CASE WHEN UNIT LIKE '%RCG%'
             THEN ( 1 * MINJUALN )
             ELSE ( FRACN*MINJUALN) 
             END ) QTY,
       HRGN,
       HRGP,
       coalesce((CASE WHEN coalesce(HRGP,'0')='0' THEN HRGN ELSE HRGP END ),'0') HRG,
       MINRPHC,
       MINJUALC,
       MAXJUALC,
       MAXRPHC,
       CBH,
       CBD
FROM (
SELECT PLUN,
       DESK,
       FRACN,
     UNIT,
       MINJUALN,
       HRGN,
       HRGP
FROM ( 
SELECT PLUP,HRGP,FLAG FROM 
(SELECT DISTINCT PRMD_PRDCD PLUP,
        coalesce(PRMD_HRGJUAL,0) HRGP,
        (CASE WHEN ALK_MEMBER='PLATINUM' THEN 'PLATINUM'
              WHEN (ALK_MEMBER='REGPLAPLUS' OR ALK_MEMBER='REGPLA') THEN 'BIRU'
              ELSE 'MERAH' END ) FLAG
FROM TBTR_PROMOMD LEFT JOIN TBTR_PROMOMD_ALOKASI ON SUBSTR(PRMD_PRDCD,1,6)||0=ALK_PRDCD
WHERE date_trunc('day',PRMD_TGLAWAL)<=now() AND date_trunc('day',PRMD_TGLAKHIR)>=now()
 AND PRMD_PRDCD LIKE :kodePLU   ) prd14 WHERE FLAG='PLATINUM' ) pla1
RIGHT JOIN ( 
SELECT PRD_PRDCD PLUN,
       PRD_DESKRIPSIPANJANG DESK,
       PRD_FRAC FRACN,
     PRD_UNIT UNIT,
       PRD_MINJUAL MINJUALN,
       PRD_HRGJUAL HRGN
FROM TBMASTER_PRODMAST
WHERE PRD_PRDCD LIKE :kodePLU) plu_pla ON PLUN=PLUP )pla3
LEFT JOIN (
SELECT PLUC,
       MINRPHC,
       MINJUALC,
       MAXJUALC,
       MAXRPHC,
       CBH,
       CBD 
FROM (
select cbd_kodepromosi kode, 
       cbd_prdcd pluC, 
      (case when cbh_minrphprodukpromo < cbh_mintotbelanja then cbh_mintotbelanja 
            when cbh_minrphprodukpromo >0 then cbh_minrphprodukpromo 
            else cbh_mintotbelanja 
            end ) minrphC, 
       cbd_minstruk minjuALC, 
       (case when cbd_maxstruk='999999' then 999999999 else cbd_maxstruk end) maxjuALC, 
       (case when cbh_maxstrkperhari='999999' then 999999999 else cbh_maxstrkperhari end) maxrphC, 
       coalesce(cbh_cashback,0) cbh, 
       coalesce(cbd_cashback,0) cbd 
from tbtr_cashback_hdr left join tbtr_cashback_dtl on cbh_kodepromosi=cbd_kodepromosi 
                       left join tbtr_cashback_alokasi on cbh_kodepromosi=cba_kodepromosi 
where date_trunc('day',cbh_tglakhir)>= now() and date_trunc('day',cbh_tglawal)<=now() 
   and ( coalesce(cba_platinum,'0')='1' ) 
  and cbh_namapromosi not like '%UNIQUE%' 
  and cbh_namapromosi not like '%PWP%' 
  and cbh_namapromosi not like '%KLIK IGR%' 
  and cbh_namapromosi not like '%ISAKU%'
  and cbh_namapromosi not like '%UNICODE%' 
  and cbh_kodepromosi not in ('CS784','CS783')
  and coalesce(cbd_recordid,'2') <>'1' 
  and  coalesce(cbd_redeempoint,0)='0' ) prd15 WHERE PLUC LIKE :kodePLU) pla ON SUBSTR(PLUN,1,6)||0=PLUC) pla2 
group by PLUN, MINRPHC, MINJUALC, MAXJUALC, MAXRPHC, cbd, cbh, HRGN, HRGP, hrg, qty ) prd16 group by pluN, HRGN, HRGP, hrg, qty)prd17)prd18
ORDER BY PLUPLA )prd4 ON PLU=PLUPLA");

        // Update kodePLU for LIKE clause
        $kodePLU = substr($kodePLU, 0, 6) . '%';
        $stmt6->bindParam(':kodePLU', $kodePLU, PDO::PARAM_STR);
        $stmt6->execute();

        // Fetch all barcode and product data
        $hrgMember = $stmt6->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
}
?>

<!-- STYLE -->
<style>
    body { font-family: Arial, sans-serif; font-size: 14px; background-color: #f9f9f9; }
    .container { width: 100%; margin: auto; }
    .section-title { font-weight: bold; margin-top: 10px; margin-bottom: 5px; }
    input, select { width: 100%; padding: 4px; box-sizing: border-box; }
    table { width: 100%; border-collapse: collapse; background-color: white; }
    table, th, td { border: 1px solid #ccc; }
    th { background-color: #0074D9; color: white; }
    td, th { padding: 4px; text-align: center; }
    .header-table td { text-align: left; background-color: #f1f1f1; }
    .section-box { margin-top: 10px; padding: 8px; border: 1px solid #ccc; background: #fff; }

    .modal-backdrop {
            z-index: 1040 !important;
        }
        .modal {
            z-index: 1050 !important;
        }
        .modal-dialog {
            z-index: 1060 !important;
        }
</style>

<!-- HTML OUTPUT -->
<head><title>Informasi & History Product</title></head>

<section class="section">
    <div class="section-header d-flex justify-content-between">
        <h1>Informasi Promosi Dan Produk</h1>
    </div>

    <div class="d-flex justify-content-between align-items-center mb-2">
    <div class="section-title">Produk</div>
    <div class="d-flex gap-2">
        <button type="button" class="btn btn-primary btn-sm" onclick="loadModalInfoLokasi()">Lokasi</button>
        <button type="button" class="btn btn-primary btn-sm" onclick="loadModalInfoPenerimaan()">Penerimaan</button>
        <button type="button" class="btn btn-primary btn-sm" onclick="loadModalInfoPenjualan()">Penjualan</button>
        <button class="btn btn-outline-primary btn-sm" onclick="toggleSection('produkContainer', this)">
            <i class="fas fa-eye-slash"></i>
        </button>
    </div>
</div>



    <!-- Kontainer yang akan di-hide/unhide -->
    <div id="produkContainer">
        <table>
            <tr>
                <td>PLU</td>
                <td>
                    <!-- Tambahkan input dengan id="kodePLU" supaya bisa diambil oleh JS -->
                    <input type="text" id="kodePLU" value="<?= htmlspecialchars($data['prd_prdcd'] ?? '') ?>" readonly>
                </td>
                <td>Flag Gdg</td>
                <td><input type="text" value="<?= htmlspecialchars($data['prd_flaggudang'] ?? '') ?>"></td>
                <td>Kd Cabang</td>
                <td><input type="text" value="<?= htmlspecialchars($data['prd_kodecabang'] ?? '') ?>"></td>
            </tr>
            <tr>
                <td>Product</td>
                <td colspan="3"><input type="text" value="<?= htmlspecialchars($data['prd_deskripsipanjang'] ?? '') ?>"></td>
                <td>Kat. Toko</td>
                <td><input type="text" value="<?= htmlspecialchars($data['prd_kategoritoko'] ?? '') ?>"></td>
            </tr>
            <tr>
                <td>Kat.Brg</td>
                <td colspan="3"><input type="text" value="<?= htmlspecialchars($data['div_dept_kat'] ?? '') ?>"></td>
                <td>Upd.</td>
                <td><input type="text" value="<?= htmlspecialchars($data['prd_create_dt'] ?? '') ?>"></td>
            </tr>
        </table>
    </div>



    


   
    <div class="d-flex justify-content-between align-items-center mt-0">
    <div class="section-title">Barcode & Harga</div>
    <button class="btn btn-sm btn-outline-primary" onclick="toggleSection('barcodeContainer', this)">
        <i class="fas fa-eye-slash"></i>
    </button>
</div>

    <div id="barcodeContainer">
    <table>
        <thead>
            <tr>
                <th>Satuan / Frac</th>
                <th>Barcode</th>
                <th>Harga Jual</th>
                <th>LCost</th>
                <th>ACost</th>
                <th>Margin Lcost</th>
                <th>Margin Acost</th>
                <th>Tag</th>
                <th>Act</th>
                <th>MinJual</th>
                <th>Flag1</th>
                <th>Flag2</th>
            </tr>
        </thead>
        <tbody>
        <?php if (!empty($barcodes)): ?>
            <?php foreach ($barcodes as $i => $row): ?>
                <tr>
                    <td><?= htmlspecialchars(($row['prd_unit'] ?? '') . ' / ' . ($row['prd_frac'] ?? '')) ?></td>
                    <td><?= htmlspecialchars($row['brc_barcode'] ?? '') ?></td>
                    <td><?= number_format($row['prd_hrgjual'] ?? 0, 2) ?></td>
                    <td><?= number_format($row['prd_lastcost'] ?? 0, 2) ?></td>
                    <td><?= number_format($row['prd_avgcost'] ?? 0, 2) ?></td>
                    <td><?= number_format($row['marginlcost'] ?? 0, 2) ?>%</td>
                    <td><?= number_format($row['marginacost'] ?? 0, 2) ?>%</td>
                    <td><?= htmlspecialchars($row['prd_kodetag'] ?? '') ?></td>
                    <td><?= htmlspecialchars($row['prd_flag_aktivasi'] ?? '') ?></td>
                    <td><?= htmlspecialchars($row['prd_minjual'] ?? '') ?></td>
                    <td><?= htmlspecialchars($row['prd_flagbkp1'] ?? '') ?></td>
                    <td><?= htmlspecialchars($row['prd_flagbkp2'] ?? '') ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="14">Data tidak ditemukan</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>

<div class="d-flex justify-content-between align-items-center mt-0">
<div class="section-title">Harga Member MM/MB/MP</div>
 <button class="btn btn-sm btn-outline-primary" onclick="toggleSection('hrgMmContainer', this)">
        <i class="fas fa-eye-slash"></i>
    </button>
</div>
 <div id="hrgMmContainer">
<table>
    <thead>
    <tr class="info">
      <th rowspan="2" class="text-center">PLU</th>
      <th colspan="3" class="text-center" style="background-color:red; color:white;">Member Merah</th>
      <th colspan="3" class="text-center" style="background-color:blue; color:white;">Member Biru</th>
	  <th colspan="3" class="text-center"  style="background-color:black; color:white;">Member Platinum</th>
    </tr>
    
	<tr class="info">
      
      <th >Harga</th>
      <th>CB</th>
      <th>Harga Net</th>
	  
	   <th>Harga</th>
      <th>CB</th>
      <th>Harga Net</th>
	  
	   <th>Harga</th>
      <th>CB</th>
      <th>Harga Net</th>
	  
    </tr>
  </thead> 
    <tbody>
        <?php if (!empty($hrgMember)): ?>
            <?php foreach ($hrgMember as $i => $row): ?>
                <tr>
                    <td><?= htmlspecialchars($row['plu'] ?? '') ?></td>
                    <td><?= htmlspecialchars($row['hrgmm'] ?? '') ?></td>
                    <td><?= number_format($row['cbmm'] ?? 0, 2) ?></td>
                    <td><?= number_format($row['hrg_netmm'] ?? 0, 2) ?></td>
                    <td><?= htmlspecialchars($row['hrgbiru'] ?? '') ?></td>
                    <td><?= number_format($row['cbbiru'] ?? 0, 2) ?></td>
                    <td><?= number_format($row['hrg_netbiru'] ?? 0, 2) ?></td>
                    <td><?= htmlspecialchars($row['hrgpla'] ?? '') ?></td>
                    <td><?= number_format($row['cbpla'] ?? 0, 2) ?></td>
                    <td><?= number_format($row['hrg_netpla'] ?? 0, 2) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="14">Data tidak ditemukan</td></tr>
        <?php endif; ?>
    </tbody>
</table>
 </div>

    

<div class="d-flex justify-content-between align-items-center mt-0">
    <div class="section-title">Promo Cashback</div>
    <button class="btn btn-sm btn-outline-primary" onclick="toggleSection('promoContainer', this)">
        <i class="fas fa-eye-slash"></i>
    </button>
</div>
 <div id="promoContainer">
<table>
    <thead>
        <tr class="primary">
            <th rowspan="2" class="text-center">#</th>
            <th rowspan="2" class="text-center">Nama Promosi CASHBACK</th>
            <th colspan="3" class="text-center">Minimum Beli/ Struk</th>
            <th rowspan="2" class="text-center">Nilai CB</th>
            <th rowspan="2" class="text-center">Sisa</th>
            <th colspan="4" class="text-center">Maximum Beli/ Struk</th>
            <th colspan="2" class="text-center">Periode</th>
            <th rowspan="2" class="text-center">Jenis Member</th>
        </tr>
        <tr class="primary">
            <th>Qty</th>
            <th>Sponsor Rp.</th>
            <th>Total Rp.</th>
            <th>Struk</th>
            <th>Member Per Hari</th>
            <th>Frek Per Event</th>
            <th>Rph Per Event</th>
            <th>Mulai</th>
            <th>Selesai</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($csbk)): ?>
            <?php $no = 1; ?>
            <?php foreach ($csbk as $i => $row): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($row['cbd_kodepromosi'] ?? '') ?></td>
                    <td><?= htmlspecialchars($row['cbd_minstruk'] ?? '') ?></td>
                    <td><?= number_format($row['cbh_minrphprodukpromo'] ?? 0, 2) ?></td>
                    <td><?= number_format($row['cbh_mintotbelanja'] ?? 0, 2) ?></td>
                    <td><?= number_format($row['cbd_cashback'] ?? 0, 2) ?></td>
                    <td><?= number_format($row['cbk_sisa'] ?? 0) ?></td>
                    <td><?= number_format($row['cbd_maxstruk'] ?? 0) ?></td>
                    <td><?= htmlspecialchars($row['cbd_maxmemberperhari'] ?? '') ?></td>
                    <td><?= htmlspecialchars($row['cbd_maxfrekperevent'] ?? '') ?></td>
                    <td><?= htmlspecialchars($row['cbd_maxrphperevent'] ?? '') ?></td>
                    <td><?= htmlspecialchars($row['cbh_tglawal'] ?? '') ?></td>
                    <td><?= htmlspecialchars($row['cbh_tglakhir'] ?? '') ?></td>
                    <td>
                        <?php
                            $jenisMember = '';
                            if ($row['cba_reguler'] == '1') $jenisMember .= 'REG ';
                            if ($row['cba_reguler_biruplus'] == '1') $jenisMember .= 'RB+ ';
                            if ($row['cba_freepass'] == '1') $jenisMember .= 'FRE ';
                            if ($row['cba_retailer'] == '1') $jenisMember .= 'RET ';
                            if ($row['cba_silver'] == '1') $jenisMember .= 'SIL ';
                            if ($row['cba_gold1'] == '1') $jenisMember .= 'GD1 ';
                            if ($row['cba_gold2'] == '1') $jenisMember .= 'GD2 ';
                            if ($row['cba_gold3'] == '1') $jenisMember .= 'GD3 ';
                            if ($row['cba_platinum'] == '1') $jenisMember .= 'PLA ';
                            echo htmlspecialchars(trim($jenisMember));
                        ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="14">Data tidak ditemukan</td></tr>
        <?php endif; ?>
    </tbody>
</table>
 </div>




    <div class="row" style="display: flex; gap: 20px; margin-top: 20px;">
        <!-- Trend Sales -->
        <div style="flex: 1;">
            <div class="section-title">TREND SALES</div>
            <table class="custom-table">
                <thead>
                    <tr><th colspan="3" class="header-center">TREND SALES</th></tr>
                    <tr><th>Bulan</th><th>QTY</th><th>RUPIAH</th></tr>
                </thead>
                <tbody>
                    <?php if (!empty($trensale)): ?>
                        <?php foreach ($trensale as $row): ?>
                            <tr><td>JAN</td><td><?= number_format($row['sls_qty_01'] ?? 0, 2) ?></td><td><?= number_format($row['sls_rph_01'] ?? 0, 2) ?></td></tr>
                            <tr><td>FEB</td><td><?= number_format($row['sls_qty_02'] ?? 0, 2) ?></td><td><?= number_format($row['sls_rph_02'] ?? 0, 2) ?></td></tr>
                            <tr><td>MAR</td><td><?= number_format($row['sls_qty_03'] ?? 0, 2) ?></td><td><?= number_format($row['sls_rph_03'] ?? 0, 2) ?></td></tr>
                            <tr><td>APR</td><td><?= number_format($row['sls_qty_04'] ?? 0, 2) ?></td><td><?= number_format($row['sls_rph_04'] ?? 0, 2) ?></td></tr>
                            <tr><td>MEI</td><td><?= number_format($row['sls_qty_05'] ?? 0, 2) ?></td><td><?= number_format($row['sls_rph_05'] ?? 0, 2) ?></td></tr>
                            <tr><td>JUN</td><td><?= number_format($row['sls_qty_06'] ?? 0, 2) ?></td><td><?= number_format($row['sls_rph_06'] ?? 0, 2) ?></td></tr>
                            <tr><td>JUL</td><td><?= number_format($row['sls_qty_07'] ?? 0, 2) ?></td><td><?= number_format($row['sls_rph_07'] ?? 0, 2) ?></td></tr>
                            <tr><td>AGS</td><td><?= number_format($row['sls_qty_08'] ?? 0, 2) ?></td><td><?= number_format($row['sls_rph_08'] ?? 0, 2) ?></td></tr>
                            <tr><td>SEP</td><td><?= number_format($row['sls_qty_09'] ?? 0, 2) ?></td><td><?= number_format($row['sls_rph_09'] ?? 0, 2) ?></td></tr>
                            <tr><td>OKT</td><td><?= number_format($row['sls_qty_10'] ?? 0, 2) ?></td><td><?= number_format($row['sls_rph_10'] ?? 0, 2) ?></td></tr>
                            <tr><td>NOV</td><td><?= number_format($row['sls_qty_11'] ?? 0, 2) ?></td><td><?= number_format($row['sls_rph_11'] ?? 0, 2) ?></td></tr>
                            <tr><td>DES</td><td><?= number_format($row['sls_qty_12'] ?? 0, 2) ?></td><td><?= number_format($row['sls_rph_12'] ?? 0, 2) ?></td></tr>
                            <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="3">Data tidak ditemukan</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>


        <!-- STOK -->
<div style="flex: 3; min-width: 700px;">
    <div class="section-title">STOK</div>
    <table class="custom-table">
        <thead>
            <tr>
                <th>LOKASI</th>
                <th>AWAL</th>
                <th>TERIMA</th>
                <th>KELUAR</th>
                <th>SALES</th>
                <th>RETUR</th>
                <th>ADJ</th>
                <th>INTRANSIT</th>
                <th>SO</th>
                <th>AKHIR</th>
                <th>AKHIR LPP</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($stok)): ?>
                <?php foreach ($stok as $row): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['lokasi']) ?></td>
                        <td><?= number_format($row['st_saldoawal']) ?></td>
                        <td><?= number_format($row['st_trfin']) ?></td>
                        <td><?= number_format($row['st_trfout']) ?></td>
                        <td><?= number_format($row['st_sales']) ?></td>
                        <td><?= number_format($row['st_retur']) ?></td>
                        <td><?= number_format($row['st_adj']) ?></td>
                        <td><?= number_format($row['st_intransit']) ?></td>
                        <td><?= number_format($row['so']) ?></td>
                        <td><?= number_format($row['st_saldoakhir']) ?></td>
                        <td><?= number_format($row['st_saldoakhir_lpp']) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="11">Data tidak ditemukan</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</section>  

    <!-- Container untuk menampung modal yang di-load via AJAX -->
    <div id="modalInfoLokasiContainer"></div>

    <!-- Container untuk menampung modal Penerimaan -->
    <div id="modalInfoPenerimaanContainer"></div>

    <!-- Container untuk menampung modal Penerimaan -->
    <div id="modalInfoPenjualanContainer"></div>

<script>
function loadModalInfoLokasi() {
    const kodePLU = document.getElementById('kodePLU').value.trim();

    if (!kodePLU) {
        alert('Kode PLU tidak boleh kosong!');
        return;
    }

    fetch('lokasi_modal.php?kodePLU=' + encodeURIComponent(kodePLU))
        .then(response => response.text())
        .then(html => {
            document.getElementById('modalInfoLokasiContainer').innerHTML = html;
            $('#modalInfoLokasi').modal('show');
        })
        .catch(error => console.error('Gagal memuat modal:', error));
}

function loadModalInfoPenerimaan() {
    const kodePLU = document.getElementById('kodePLU').value.trim();

    if (!kodePLU) {
        alert('Kode PLU tidak boleh kosong!');
        return;
    }

    fetch('penerimaan_modal.php?kodePLU=' + encodeURIComponent(kodePLU))
        .then(response => response.text())
        .then(html => {
            document.getElementById('modalInfoPenerimaanContainer').innerHTML = html;
            $('#modalInfoPenerimaan').modal('show');
        })
        .catch(error => console.error('Gagal memuat modal:', error));
}

function loadModalInfoPenjualan() {
    const kodePLU = document.getElementById('kodePLU').value.trim();

    if (!kodePLU) {
        alert('Kode PLU tidak boleh kosong!');
        return;
    }

    fetch('penjualan_modal.php?kodePLU=' + encodeURIComponent(kodePLU))
        .then(response => response.text())
        .then(html => {
            document.getElementById('modalInfoPenjualanContainer').innerHTML = html;
            $('#modalInfoPenjualan').modal('show');
        })
        .catch(error => console.error('Gagal memuat modal:', error));
}

function toggleSection(containerId, btn) {
    const container = document.getElementById(containerId);
    const icon = btn.querySelector('i');

    if (container.style.display === 'none') {
        container.style.display = 'block';
        if (icon) {
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        }
    } else {
        container.style.display = 'none';
        if (icon) {
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    }
}

</script>

<?php
require_once '../layout/_bottom.php';
?>